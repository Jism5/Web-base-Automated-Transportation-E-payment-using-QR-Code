<?php 
if(isset($_POST['save'])){
  $des = $_POST['des'];
  if(!empty($des)){
      $query = "INSERT INTO users_log (destination) VALUES('$des')";
      $result = $conn->query($query);
      if($result){
        echo "Course is inserted successfully";
      }  
    }
  }

?>