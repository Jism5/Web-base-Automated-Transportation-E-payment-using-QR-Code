<?php
 require_once "controllerUserData.php"; require_once "check.php";

                        $email = $_SESSION['email'];
                            $query = "SELECT * FROM users_log WHERE email = '$email'";
                            $result = mysqli_query($con, $query);
                            $row = mysqli_fetch_assoc($result);
                            $id = $row['id'];

if(isset($_POST['update_stud_data']))
{
    
    $name = $_POST['name'];
    $email = $_POST['email'];

    $query = "UPDATE users_log SET name='$name', email='$email' WHERE id='$id' ";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['status'] = "Data Updated Successfully";
        header("Location: index.php");
    }
    else
    {
        $_SESSION['status'] = "Not Updated";
        header("Location: index.php");
    }
}

?>