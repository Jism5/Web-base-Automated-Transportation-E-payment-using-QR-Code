<?php 
$conn = mysqli_connect('localhost', 'root', '', 'toda_database');
?>