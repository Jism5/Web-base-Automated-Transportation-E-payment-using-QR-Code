<?php
if(issert($_POST['addnew'])) {
	require_once("connection.php");
	$sql = "INSERT INTO place (destination, price) VALUES ('" . $_POST["des"] . "', '" . $_POST["pri"] . "')";
	mysqli_query($con,$sql);
	$current_id = mysqli_insert_id($conn);
	if(!empty($current_id)) {
		$message = "New User Added Successfully";
		header("location: index.php");
	}
}
