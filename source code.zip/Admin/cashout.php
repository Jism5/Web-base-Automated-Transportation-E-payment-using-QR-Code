<?php
require_once "controllerUserData.php";
require_once "check.php";

$plate = $_GET['plate'];

$sql = mysqli_query($con, "SELECT * FROM riders_log WHERE plate = '$plate'");
$row = mysqli_fetch_assoc($sql);
$id =$row['id'];
$name =$row['name'];
$tplate =$row['plate'];
$intime =$row['time_in'];
$outime =$row['time_out'];
$cashout =$row['storage'];
$type = "cash_out";
$mark = "old";

if($row){
   $sql = mysqli_query($con, "INSERT INTO history (id,usermail,username,mark,riderid,ridername, plate,fee,destination,qrtime,created, time_in, time_out,t_type,cashout)  VALUES(0,'','','$mark','$id','$name','$tplate',0,'',0,0,'$intime','$outime','$type','$cashout')");
    $qry = mysqli_query($con, "UPDATE riders_log SET time_in = '', time_out = '', storage = 0 , cashout_status = '' WHERE plate = '$plate'");
    header("location: cashout_receipt.php?name=$name&&plate=$tplate&&int=$intime&&ont=$outime&&amount=$cashout");
}else{
    echo  $con->error;
}