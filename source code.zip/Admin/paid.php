<?php
require_once "controllerUserData.php";
require_once "check.php";

if(isset($_GET['did'])){
    $id = $_GET['did'];
    $sql = mysqli_query($con, "UPDATE riders_log SET storage = 0, boundery = 0 WHERE id = $id");
    if($sql){
       header("location: index.php");
    }
}